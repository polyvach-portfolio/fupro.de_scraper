import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

public class CL {

    HtmlUnitDriver driver;
    String cssSelector = "#ligen > li.item-631";
    public String folderLvl1Name = "";
    public String dirLevel2Name = "";
    public String dirLevel3Name = "";
    public static File dirLevel1 = null;
    public static File dirLevel2 = null;
    public static File dirLevel3 = null;


    CL(){}

    CL(HtmlUnitDriver driver){
        this.driver = driver;
        this.driver.get(Main.domen);
    }
    public void parsePage() throws IOException {
        String folderName = (new WebDriverWait(driver, 10))
                .until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(cssSelector + " > a"))).getText();
        folderLvl1Name = folderName;


        dirLevel1 = new File((Main.mainFolder + folderName).replaceAll(" ", "_").replaceAll("/", "+"));
        boolean createdDirLevel1 = dirLevel1.mkdir();
        if(createdDirLevel1)
            System.out.println(">>Folder '" + folderName + "' has been created");

        Map<String, String> urlsInfo = new HashMap<String, String>();
        WebElement menuList = (new WebDriverWait(driver, 10))
                .until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(cssSelector + " > a")));
        getTable(menuList.getAttribute("href"), dirLevel1.getAbsolutePath());


    }

    public void getTable(String url, String dirLevel1) throws IOException {
        System.out.println("Start parsing '" + url + "'");


//            //Start -> Create folder lvl-2
//            dirLevel2 = new File((dirLevel1 + "\\" + dirLevel2Name.trim()).replaceAll(" ", "_"));
//            boolean createdDirLevel2 = dirLevel2.mkdir();
//            if(createdDirLevel2)
//                System.out.println("- Folder '"+ dirLevel2.getName() +"' has been created");
//            //End -> Create folder lvl-2


        Document doc = Jsoup.connect(url).get();
        Elements prognoseUrls = doc.select("#nav-submenu > ul > li > a");
        String newUrl = "";
        String newUrlProg = "";
        String newUrlProgStat = "";

        for (Element prognoseUrl : prognoseUrls) {
            if(prognoseUrl.text().contains("Prognose") && !prognoseUrl.text().contains("Prognose Statistik")){
                newUrlProg = prognoseUrl.attr("href");

            }
            if(prognoseUrl.text().contains("Prognose Statistik")){
                newUrlProgStat = prognoseUrl.attr("href");
            }
        }

        scrapEL(newUrlProg, newUrlProgStat);

        System.out.println("End parsing '" + url + "'\n");
    }

    public void scrapEL(String urlPrognose, String urlPrognoseStat) throws IOException {
        Document docPrognose = Jsoup.connect("https://fupro.de" + urlPrognose).get();
        Element tablesBlockPrognose = docPrognose.select(".tab-content").first();
        Elements blocksWithTablesPrognose = tablesBlockPrognose.select(".tab-pane");


        Document docPrognoseStat = Jsoup.connect("https://fupro.de" + urlPrognoseStat).get();
        Element tablesBlockPrognoseStat = docPrognoseStat.select(".tab-content").first();
        Elements blocksWithTablesPrognoseStat = tablesBlockPrognoseStat.select(".tab-pane");

        String groupName = "";
        ArrayList<Elements> prognoseTables = new ArrayList<>();
        ArrayList<Elements> prognoseStatTables = new ArrayList<>();
        HashMap<String, Elements> rowsPrognose = new HashMap<String, Elements>();
        HashMap<String, Elements> rowsPrognoseStat = new HashMap<String, Elements>();

        for(Element block: blocksWithTablesPrognose){
            groupName = block.select("div.divh4").first().text();
            Elements rowsProg = null;
            if(block.select("tbody > tr") != null){
                rowsProg = block.select("tbody > tr");
            }
            rowsPrognose.put(groupName, rowsProg);
        }

        for(Element block: blocksWithTablesPrognoseStat){
            groupName = block.select("div.divh4").first().text();
            Elements rowsProg = null;
            if(block.select("tbody > tr") != null){
                rowsProg = block.select("tbody > tr");
            }
            rowsPrognoseStat.put(groupName, rowsProg);
        }


        for (Map.Entry prognoseStat: rowsPrognoseStat.entrySet()) {
            for(Map.Entry prognose: rowsPrognose.entrySet()){
                if(prognoseStat.getKey().toString().equals(prognose.getKey().toString())){
                    dirLevel2Name = prognoseStat.getKey().toString();
                    dirLevel2 = new File((dirLevel1.getAbsolutePath() + "\\" + dirLevel2Name.trim()).replaceAll(" ", "_").replaceAll("/", "+"));
                    boolean createdDirLevel2 = dirLevel2.mkdir();
                    if(createdDirLevel2)
                        System.out.println("<<Folder '" + dirLevel2Name + "' has been created");

                    Elements prognoseStatElems = (Elements) prognoseStat.getValue();
                    Elements prognoseElems = (Elements) prognose.getValue();
                    boolean flag = true;
                    for (Element headlineStat : prognoseStatElems) {
                        flag = true;
                        String date = "";
                        Elements tdsStat = headlineStat.select("td");

                        date = correctDate(headlineStat.select("td").get(0).text());

                        if(!date.equals("")){
                            dirLevel3Name = date;
                        }

                        for(Element headline : prognoseElems){

                            Elements tds = headline.select("td");
                            if(tdsStat.get(0).text().equals(tds.get(0).text()) && tdsStat.get(1).text().equals(tds.get(1).text())
                                    && tdsStat.get(3).text().equals(tds.get(3).text())){
                                setInfoXML(dirLevel2.getAbsolutePath(), dirLevel3Name, dirLevel1.getName(),  date,
                                        tds.get(1).text(), tds.get(3).text(), tds.get(10).text(), tds.get(8).text(), tds.get(9).text(),
                                        tdsStat.get(5).text(), tdsStat.get(4).text());
                                flag = false;
                            }

                        }
                        if(flag){
                            setInfoXML(dirLevel2.getAbsolutePath(), dirLevel3Name, dirLevel2.getName(), date, tdsStat.get(1).text(),
                                    tdsStat.get(3).text(), "", "", "", tdsStat.get(5).text(), tdsStat.get(4).text());
                        }
                    }
                }
            }
        }
    }


    public String correctDate(String date){
        String dateStr = date;
        String[] dates = dateStr.split(Pattern.quote("."));
        return dates[2]+"-"+dates[1]+"-"+dates[0];
    }

    public static void setInfoXML(String path, String dirLevel3Name, String leagueStr, String dateStr, String homeTeamStr, String awayTeamStr,
                                  String pred2Str, String pred1Str, String predXStr, String predMatchScoreStr, String matchScoreStr){
        try {
            org.w3c.dom.Document document = (org.w3c.dom.Document) DocumentBuilderFactory.newInstance()
                    .newDocumentBuilder().newDocument();

            org.w3c.dom.Element matches = document.createElement("Matches");
            document.appendChild(matches);

            org.w3c.dom.Element match = document.createElement("Match");
            matches.appendChild(match);

            org.w3c.dom.Element sport = (org.w3c.dom.Element) document.createElement("Sport");
            sport.setTextContent("Soccer");
            match.appendChild(sport);

            org.w3c.dom.Element sourceMtch = (org.w3c.dom.Element) document.createElement("Source");
            sourceMtch.setTextContent("Fupro.de");
            match.appendChild(sourceMtch);

            org.w3c.dom.Element league = (org.w3c.dom.Element) document.createElement("League");
            league.setTextContent(leagueStr);
            match.appendChild(league);

            org.w3c.dom.Element date = (org.w3c.dom.Element) document.createElement("Date");
            date.setTextContent(dateStr);
            match.appendChild(date);

            org.w3c.dom.Element homeTeam = (org.w3c.dom.Element) document.createElement("HomeTeam");
            homeTeam.setTextContent(homeTeamStr);
            match.appendChild(homeTeam);

            org.w3c.dom.Element awayTeam = (org.w3c.dom.Element) document.createElement("AwayTeam");
            awayTeam.setTextContent(awayTeamStr);
            match.appendChild(awayTeam);

            if(!pred1Str.equals("")){
                org.w3c.dom.Element pred1 = (org.w3c.dom.Element) document.createElement("Pred1");
                pred1.setTextContent(String.format("%.2f", 100/Double.parseDouble(pred1Str)));
                match.appendChild(pred1);
            }

            if(!predXStr.equals("")) {
                org.w3c.dom.Element predX = (org.w3c.dom.Element) document.createElement("PredX");
                predX.setTextContent(String.format("%.2f", 100 / Double.parseDouble(predXStr)));
                match.appendChild(predX);
            }
            if(!pred2Str.equals("")) {
                org.w3c.dom.Element pred2 = (org.w3c.dom.Element) document.createElement("Pred2");
                pred2.setTextContent(String.format("%.2f", 100 / Double.parseDouble(pred2Str)));
                match.appendChild(pred2);
            }
            org.w3c.dom.Element predMatchScore = (org.w3c.dom.Element) document.createElement("PredMatchScore");
            predMatchScore.setTextContent(predMatchScoreStr);
            match.appendChild(predMatchScore);

            org.w3c.dom.Element matchScore = (org.w3c.dom.Element) document.createElement("MatchScore");
            matchScore.setTextContent(matchScoreStr);
            match.appendChild(matchScore);

            File dirLevel3 = new File(path + "\\" + dirLevel3Name);
            boolean createdDirLevel3 = dirLevel3.mkdir();
            if(createdDirLevel3)
                System.out.println("-- Folder '"+ dirLevel3.getName() +"' has been created");

            // Сохранить текстовое представление XML документа в файл
            String xmlFileName = (homeTeamStr + " - " + awayTeamStr).replaceAll("/", " + ");
            System.out.print(">>>> '" + xmlFileName.trim() + "'");


            Transformer transformer = TransformerFactory.newInstance()
                    .newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            DOMSource source = new DOMSource((org.w3c.dom.Node) document);
            String endPathFile = dirLevel3.getAbsolutePath() + "/" + xmlFileName + ".xml";
            StreamResult result = new StreamResult(new FileOutputStream(endPathFile));
            transformer.transform(source, result);

            System.out.println(" -> xml file saved!");

        } catch (TransformerConfigurationException ex) {
            ex.printStackTrace();
        } catch (TransformerException ex) {
            ex.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
    }












}
