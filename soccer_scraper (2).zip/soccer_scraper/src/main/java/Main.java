import org.apache.commons.io.IOUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.select.Elements;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.net.URLDecoder;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;


public class Main {
    public static HtmlUnitDriver driver;
    public static String domen = "https://fupro.de/";
    public static String subMenu = "nav-submenu";
    public static String lastDate = "";
    public static String lastTime = "";
    public static String mainFolder = ""; //file must has this path
    public static String folderLvl1Name = "";

    public static List<String> cssSelectorsLists = new ArrayList<>();
    public static String dirLevel3Name = "";

    public static File dirLevel2 = null;


    public static void main(String[] args) {
        driver = new HtmlUnitDriver();
        driver.setJavascriptEnabled(true);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        try(FileInputStream inputStream = new FileInputStream(new File(".").getAbsolutePath() + "\\folder_path.txt")) {
            mainFolder = IOUtils.toString(inputStream);
            // do something with everything string
        } catch (FileNotFoundException e) {
            System.out.println("File with path not found!");
        } catch (IOException e) {
            e.printStackTrace();
        }
        java.util.logging.Logger.getLogger("com.gargoylesoftware").setLevel(Level.OFF);
        java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(Level.OFF);

        for(int i = 0; i < args.length; i++){
            for(int j = i+1; j < args.length; j++){
                if(args[i] == args[j]){
                    System.out.println("Incorrect parameters");
                    System.exit(0);
                }
            }
        }
        if(args.length > 0){
            for(int i = 0; i < args.length; i++){
                if ("1".equals(args[i])) {
                    cssSelectorsLists.add("#ligen > li.item-469.deeper.dropdown.parent");
                } else if ("2".equals(args[i])) {
                    cssSelectorsLists.add("#ligen > li.item-480.deeper.dropdown.parent");
                } else if ("3".equals(args[i])) {
                    CL cl = new CL(driver);
                    System.out.println("---START CL---");
                    try {
                        cl.parsePage();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    System.out.println("---END CL---");
                } else if ("4".equals(args[i])) {
                    EL el = new EL(driver);
                    System.out.println("---START EL---");
                    try {
                        el.parsePage();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    System.out.println("---END EL---");
                } else if ("5".equals(args[i])) {
                    cssSelectorsLists.add("#ligen > li.item-469.deeper.dropdown.parent");
                }
            }
        }else{
            cssSelectorsLists.addAll(Arrays.asList(
                    "#ligen > li.item-469.deeper.dropdown.parent",
                    "#ligen > li.item-480.deeper.dropdown.parent",
                    "#ligen > li.item-687.deeper.dropdown.parent"
            ));
            CL cl = new CL(driver);
            EL el = new EL(driver);
            System.out.println("---START CL---");
            try {
                System.out.println("---START CL---");
                cl.parsePage();
                System.out.println("---END CL---");
                System.out.println("---START EL---");
                el.parsePage();
                System.out.println("---END EL---");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


        driver.get(domen);

        for(String item : cssSelectorsLists){
            boolean isInternational = false;
            //Start -> Create folder lvl-1
            String folderName = (new WebDriverWait(driver, 10))
                    .until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(item + " > a"))).getText();
            folderLvl1Name = folderName;
            if(folderName.equals("International")) isInternational = true;

            File dirLevel1 = new File((mainFolder + folderName).replaceAll(" ", "_").replaceAll("/", "+"));
            boolean createdDirLevel1 = dirLevel1.mkdir();
            if(createdDirLevel1)
                System.out.println(">>Folder '" + folderName + "' has been created");
            //End -> Create folder lvl-1
            Map<String, String> urlsInfo = new HashMap<String, String>();
            try{
                WebElement menuList = (new WebDriverWait(driver, 10))
                        .until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(item + " > ul")));
                List<WebElement> urls = menuList.findElements(By.tagName("a"));
                ArrayList<String> strUrls = new ArrayList<String>();
                ArrayList<String> strFolderNames = new ArrayList<String>();

                for(WebElement elem: urls){
                    urlsInfo.put(elem.getAttribute("href"), elem.getAttribute("innerHTML"));
                }
                for (Map.Entry entry: urlsInfo.entrySet()) {
                    String url = entry.getKey().toString();
                    String folder = entry.getValue().toString();
                    getTable(url, folder, dirLevel1.getAbsolutePath(), isInternational);
                }
            }catch (TimeoutException ex){
                WebElement menuList = (new WebDriverWait(driver, 10))
                        .until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(item + " > a")));
                urlsInfo.put(menuList.getAttribute("href"), menuList.getAttribute("innerHTML"));
                for (Map.Entry entry: urlsInfo.entrySet()) {
                    String url = entry.getKey().toString();
                    String folder = entry.getValue().toString();
                    getTable(url, folder, dirLevel1.getAbsolutePath(), isInternational);
                }
            }

        }

    }


    public static void getTable(String url, String dirLevel2Name, String dirLevel1, boolean isInternational){
        System.out.println("Start parsing '" + url + "'");
        try {
            if(dirLevel2Name.equals("WM 2014")) throw new NullPointerException();
            //Start -> Create folder lvl-2
            dirLevel2 = new File((dirLevel1 + "\\" + dirLevel2Name.trim()).replaceAll(" ", "_"));
            boolean createdDirLevel2 = dirLevel2.mkdir();
            if(createdDirLevel2)
                System.out.println("- Folder '"+ dirLevel2.getName() +"' has been created");
            //End -> Create folder lvl-2


            Document doc = Jsoup.connect(url).get();
            Elements prognoseUrls = doc.select("#nav-submenu > ul > li > a");
            String newUrl = "";
            for (Element prognoseUrl : prognoseUrls) {
                if(folderLvl1Name.equals("CL") || folderLvl1Name.equals("EL")){
                    if(prognoseUrl.text().contains("Prognose") && !prognoseUrl.text().contains("Prognose Statistik"))
                        newUrl = prognoseUrl.attr("href");
                }else{
                    if(prognoseUrl.text().contains("Prognose Statistik"))
                        newUrl = prognoseUrl.attr("href");
                }

            }

//            String newUrl = doc.select("#nav-submenu > ul > li:nth-of-type(3) > a").attr("href");
//            if(newUrl.isEmpty())
//                newUrl = doc.select("#nav-submenu > ul > li:nth-of-type(2) > a").attr("href");
            doc = Jsoup.connect("https://fupro.de" + newUrl).get();
            Element tablesBlock = doc.select(".tab-content").first();
            Elements newsHeadlines = null;
            if(tablesBlock.select("tbody > tr") != null){
                newsHeadlines = tablesBlock.select("tbody > tr");
            }else{
                newsHeadlines = tablesBlock.select("div > tbody > tr");
            }

            for (Element headline : newsHeadlines) {
                String date = headline.select("td").get(0).text().split(" ")[0];
                String time = "";
                Elements tds = headline.select("td");
                if(!date.equals("")){
                    dirLevel3Name = correctDate(date);
                    lastDate = correctDate(date);
                    if(tds.get(0).text().split(" ").length > 1)
                        lastTime = tds.get(0).text().split(" ")[1];

                }

                if(tds.size() > 7){
                    String[] mass = internationalMass(dirLevel2Name);
                    if(isInternational){
                        setInfoXML(dirLevel2.getAbsolutePath(),mass[0].trim(), mass[1].trim(), lastDate, lastTime, tds.get(1).text(), tds.get(3).text(), tds.get(9).text(),
                                tds.get(7).text(), tds.get(8).text(), tds.get(5).text(), tds.get(4).text());
                    }else{
                        if(folderLvl1Name.equals("EL") || folderLvl1Name.equals("CL")){
                            setInfoXML(dirLevel2.getAbsolutePath(),"", dirLevel2Name, lastDate, lastTime, tds.get(1).text(), tds.get(3).text(), tds.get(10).text(),
                                    tds.get(8).text(), tds.get(9).text(), "", tds.get(4).text());
                        }else {
                            setInfoXML(dirLevel2.getAbsolutePath(),"Germany", dirLevel2Name, lastDate, lastTime, tds.get(1).text(), tds.get(3).text(), tds.get(9).text(),
                                    tds.get(7).text(), tds.get(8).text(), tds.get(5).text(), tds.get(4).text());
                        }

                    }

                }else{
                    setInfoXML(dirLevel2.getAbsolutePath(),dirLevel2Name, lastDate, tds.get(1).text(), tds.get(3).text(), tds.get(5).text(), tds.get(4).text());
                }

            }

        } catch (NullPointerException e) {
            System.out.println("WM_2014");
            scrapWM2014(dirLevel1);
            System.out.println("EM2014_Qualifikation");
            scrapEMQ2016(dirLevel1);
            System.exit(0);
        }catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("End parsing '" + url + "'\n");
    }

    public static void scrapWM2014(String path){
        System.out.println("Start parsing 'https://fupro.de/wm2014-prognos'");
        Document doc = null;
        try {
            doc = Jsoup.connect("https://fupro.de/wm2014-prognose").get();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Elements tableWM2014 = doc.select(".item-page > table:nth-child(3) > tbody:nth-child(1) > tr");
        File dirLevel4 = null;
        for (Element tableRow : tableWM2014) {
            if(tableRow.attr("class").equals("resulttableheadline") || !tableRow.hasAttr("class")){
                File dirLevel3 = new File(path + "\\WM2014");
                boolean createdDirLevel3 = dirLevel3.mkdir();
                if(createdDirLevel3)
                    System.out.println("-- Folder '"+ dirLevel3.getName() +"' has been created");

                dirLevel4 = new File(dirLevel3.getAbsolutePath() + "\\" + tableRow.getElementsByTag("h3").text());
                boolean createdDirLevel4 = dirLevel4.mkdir();
                if(createdDirLevel4)
                    System.out.println(">>>> Folder '"+ dirLevel4.getName() +"' has been created");
            }else{
                if(tableRow.attr("class").equals("resulttableline_wm2") || tableRow.attr("class").equals("resulttableline_wm1")){
                    Elements cells = tableRow.getElementsByTag("td");
                    try {
                        org.w3c.dom.Document document = (org.w3c.dom.Document) DocumentBuilderFactory.newInstance()
                                .newDocumentBuilder().newDocument();

                        org.w3c.dom.Element matches = document.createElement("Matches");
                        document.appendChild(matches);

                        org.w3c.dom.Element match = document.createElement("Match");
                        matches.appendChild(match);

                        org.w3c.dom.Element sport = (org.w3c.dom.Element) document.createElement("Sport");
                        sport.setTextContent("Soccer");
                        match.appendChild(sport);

                        org.w3c.dom.Element sourceMtch = (org.w3c.dom.Element) document.createElement("Source");
                        sourceMtch.setTextContent("Fupro.de");
                        match.appendChild(sourceMtch);

                        org.w3c.dom.Element country = (org.w3c.dom.Element) document.createElement("Country");
                        country.setTextContent("");
                        match.appendChild(country);

                        org.w3c.dom.Element league = (org.w3c.dom.Element) document.createElement("League");
                        league.setTextContent(dirLevel4.getName());
                        match.appendChild(league);

//                        org.w3c.dom.Element date = (org.w3c.dom.Element) document.createElement("Date");
//                        date.setTextContent("");
//                        match.appendChild(date);
//
//                        org.w3c.dom.Element time = (org.w3c.dom.Element) document.createElement("Time");
//                        time.setTextContent("");
//                        match.appendChild(time);

                        org.w3c.dom.Element homeTeam = (org.w3c.dom.Element) document.createElement("HomeTeam");
                        homeTeam.setTextContent(cells.get(0).text().trim());
                        match.appendChild(homeTeam);

                        org.w3c.dom.Element awayTeam = (org.w3c.dom.Element) document.createElement("AwayTeam");
                        awayTeam.setTextContent(cells.get(2).text().trim());
                        match.appendChild(awayTeam);


                        org.w3c.dom.Element pred1 = (org.w3c.dom.Element) document.createElement("Pred1");
                        pred1.setTextContent(String.format("%.2f", 100/Double.parseDouble(cells.get(7).text())));
                        match.appendChild(pred1);

                        org.w3c.dom.Element predX = (org.w3c.dom.Element) document.createElement("PredX");
                        predX.setTextContent(String.format("%.2f", 100/Double.parseDouble(cells.get(8).text())));
                        match.appendChild(predX);

                        org.w3c.dom.Element pred2 = (org.w3c.dom.Element) document.createElement("Pred2");
                        pred2.setTextContent(String.format("%.2f", 100/Double.parseDouble(cells.get(9).text())));
                        match.appendChild(pred2);

                        org.w3c.dom.Element predMatchScore = (org.w3c.dom.Element) document.createElement("PredMatchScore");
                        predMatchScore.setTextContent("");
                        match.appendChild(predMatchScore);

                        org.w3c.dom.Element matchScore = (org.w3c.dom.Element) document.createElement("MatchScore");
                        matchScore.setTextContent(cells.get(3).text());
                        match.appendChild(matchScore);

//                        File dirLevel3 = new File(path + "\\" + dirLevel3Name);
//                        boolean createdDirLevel3 = dirLevel3.mkdir();
//                        if(createdDirLevel3)
//                            System.out.println("-- Folder '"+ dirLevel3.getName() +"' has been created");

                        // Сохранить текстовое представление XML документа в файл
                        String xmlFileName = (cells.get(0).text().trim() + " - " + cells.get(2).text().trim()).replaceAll("/", " + ");
                        System.out.print(">>>> '" + xmlFileName.trim() + "'");


                        Transformer transformer = TransformerFactory.newInstance()
                                .newTransformer();
                        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
                        DOMSource source = new DOMSource((org.w3c.dom.Node) document);
                        String endPathFile = dirLevel4.getAbsolutePath() + "/" + xmlFileName + ".xml";
                        StreamResult result = new StreamResult(new FileOutputStream(endPathFile));
                        transformer.transform(source, result);

                        System.out.println(" -> xml file saved!");

                    } catch (TransformerConfigurationException ex) {
                        ex.printStackTrace();
                    } catch (TransformerException ex) {
                        ex.printStackTrace();
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (ParserConfigurationException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        System.out.println("End parsing 'https://fupro.de/wm2014-prognos'");
    }

    public static void scrapEMQ2016(String path){
        System.out.println("Start parsing 'https://fupro.de/emq2016-prognose-statistik'");
        String actualDate = "";
        Document doc = null;
        try {
            doc = Jsoup.connect("https://fupro.de/emq2016-prognose-statistik").get();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Elements tableWM2014 = doc.select(".item-page > table:nth-child(5) > tbody:nth-child(1) > tr");
        File dirLevel4 = null;
        File dirLevel5 = null;

        File dirLevel3 = new File(path + "\\EM2016_Qualifikation");
        boolean createdDirLevel3 = dirLevel3.mkdir();
        if(createdDirLevel3)
            System.out.println("-- Folder '"+ dirLevel3.getName() +"' has been created");

        for (Element tableRow : tableWM2014) {
            if(tableRow.attr("class").equals("resulttableheadline") || !tableRow.hasAttr("class")){
                dirLevel4 = new File(dirLevel3.getAbsolutePath() + "\\" + tableRow.getElementsByTag("h3").text());
                boolean createdDirLevel4 = dirLevel4.mkdir();
                if(createdDirLevel4)
                    System.out.println(">>>> Folder '"+ dirLevel4.getName() +"' has been created");
            }else{
                if(tableRow.attr("class").equals("resulttableline_wm2") || tableRow.attr("class").equals("resulttableline_wm1")){
                    Elements cells = tableRow.getElementsByTag("td");
                    try {
                        String correctDate = correctDate(cells.get(0).text());
                        org.w3c.dom.Document document = (org.w3c.dom.Document) DocumentBuilderFactory.newInstance()
                                .newDocumentBuilder().newDocument();

                        org.w3c.dom.Element matches = document.createElement("Matches");
                        document.appendChild(matches);

                        org.w3c.dom.Element match = document.createElement("Match");
                        matches.appendChild(match);

                        org.w3c.dom.Element sport = (org.w3c.dom.Element) document.createElement("Sport");
                        sport.setTextContent("Soccer");
                        match.appendChild(sport);

                        org.w3c.dom.Element sourceMtch = (org.w3c.dom.Element) document.createElement("Source");
                        sourceMtch.setTextContent("Fupro.de");
                        match.appendChild(sourceMtch);

                        org.w3c.dom.Element country = (org.w3c.dom.Element) document.createElement("Country");
                        country.setTextContent("");
                        match.appendChild(country);

                        org.w3c.dom.Element league = (org.w3c.dom.Element) document.createElement("League");
                        league.setTextContent(dirLevel4.getName());
                        match.appendChild(league);

                        org.w3c.dom.Element date = (org.w3c.dom.Element) document.createElement("Date");
                        date.setTextContent(correctDate);
                        match.appendChild(date);

                        org.w3c.dom.Element time = (org.w3c.dom.Element) document.createElement("Time");
                        time.setTextContent("");
                        match.appendChild(time);

                        org.w3c.dom.Element homeTeam = (org.w3c.dom.Element) document.createElement("HomeTeam");
                        homeTeam.setTextContent(cells.get(1).text().trim());
                        match.appendChild(homeTeam);

                        org.w3c.dom.Element awayTeam = (org.w3c.dom.Element) document.createElement("AwayTeam");
                        awayTeam.setTextContent(cells.get(3).text().trim());
                        match.appendChild(awayTeam);


//                        org.w3c.dom.Element pred1 = (org.w3c.dom.Element) document.createElement("Pred1");
//                        pred1.setTextContent(String.format("%.2f", 100/Double.parseDouble(cells.get(7).text())));
//                        match.appendChild(pred1);
//
//                        org.w3c.dom.Element predX = (org.w3c.dom.Element) document.createElement("PredX");
//                        predX.setTextContent(String.format("%.2f", 100/Double.parseDouble(cells.get(8).text())));
//                        match.appendChild(predX);
//
//                        org.w3c.dom.Element pred2 = (org.w3c.dom.Element) document.createElement("Pred2");
//                        pred2.setTextContent(String.format("%.2f", 100/Double.parseDouble(cells.get(9).text())));
//                        match.appendChild(pred2);

                        org.w3c.dom.Element predMatchScore = (org.w3c.dom.Element) document.createElement("PredMatchScore");
                        predMatchScore.setTextContent(cells.get(5).text());
                        match.appendChild(predMatchScore);

                        org.w3c.dom.Element matchScore = (org.w3c.dom.Element) document.createElement("MatchScore");
                        matchScore.setTextContent(cells.get(4).text());
                        match.appendChild(matchScore);

                        if(!actualDate.equals(correctDate(cells.get(0).text()))){
                            dirLevel5 = new File(dirLevel4.getAbsolutePath() + "\\" + correctDate);
                            boolean createdDirLevel5 = dirLevel5.mkdir();
                            if(createdDirLevel5)
                                System.out.println("-- Folder '"+ dirLevel5.getName() +"' has been created");
                        }
                        // Сохранить текстовое представление XML документа в файл
                        String xmlFileName = (cells.get(1).text().trim() + " - " + cells.get(3).text().trim()).replaceAll("/", " + ");
                        System.out.print(">>>> '" + xmlFileName + "'");


                        Transformer transformer = TransformerFactory.newInstance()
                                .newTransformer();
                        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
                        DOMSource source = new DOMSource((org.w3c.dom.Node) document);
                        String endPathFile = dirLevel5.getAbsolutePath() + "/" + xmlFileName + ".xml";
                        StreamResult result = new StreamResult(new FileOutputStream(endPathFile));
                        transformer.transform(source, result);

                        System.out.println(" -> xml file saved!");

                    } catch (TransformerConfigurationException ex) {
                        ex.printStackTrace();
                    } catch (TransformerException ex) {
                        ex.printStackTrace();
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (ParserConfigurationException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        System.out.println("End parsing 'https://fupro.de/emq2016-prognose-statistik'");
    }

    public static String[] internationalMass(String internStr){
        if(internStr.contains("_-_")) return internStr.split("_-_");
        else return internStr.split("-");
    }

    public static String correctDate(String date){
        String[] mass = null;
        if(date.contains(".")) mass = date.split(Pattern.quote("."));
        else return date;

        return mass[2]+"-"+mass[1]+"-"+mass[0];
    }

    public static void setInfoXML(String path, String countryStr, String leagueStr, String dateStr, String timeStr,
                                  String homeTeamStr, String awayTeamStr, String pred2Str, String pred1Str, String predXStr, String predMatchScoreStr, String matchScoreStr){
        try {
            org.w3c.dom.Document document = (org.w3c.dom.Document) DocumentBuilderFactory.newInstance()
                    .newDocumentBuilder().newDocument();

            org.w3c.dom.Element matches = document.createElement("Matches");
            document.appendChild(matches);

            org.w3c.dom.Element match = document.createElement("Match");
            matches.appendChild(match);

            org.w3c.dom.Element sport = (org.w3c.dom.Element) document.createElement("Sport");
            sport.setTextContent("Soccer");
            match.appendChild(sport);

            org.w3c.dom.Element sourceMtch = (org.w3c.dom.Element) document.createElement("Source");
            sourceMtch.setTextContent("Fupro.de");
            match.appendChild(sourceMtch);

            org.w3c.dom.Element country = (org.w3c.dom.Element) document.createElement("Country");
            country.setTextContent(countryStr);
            match.appendChild(country);

            org.w3c.dom.Element league = (org.w3c.dom.Element) document.createElement("League");
            league.setTextContent(leagueStr);
            match.appendChild(league);

            org.w3c.dom.Element date = (org.w3c.dom.Element) document.createElement("Date");
            date.setTextContent(correctDate(dateStr));
            match.appendChild(date);

            org.w3c.dom.Element time = (org.w3c.dom.Element) document.createElement("Time");
            time.setTextContent(timeStr);
            match.appendChild(time);

            org.w3c.dom.Element homeTeam = (org.w3c.dom.Element) document.createElement("HomeTeam");
            homeTeam.setTextContent(homeTeamStr);
            match.appendChild(homeTeam);

            org.w3c.dom.Element awayTeam = (org.w3c.dom.Element) document.createElement("AwayTeam");
            awayTeam.setTextContent(awayTeamStr);
            match.appendChild(awayTeam);


            org.w3c.dom.Element pred1 = (org.w3c.dom.Element) document.createElement("Pred1");
            pred1.setTextContent(String.format("%.2f", 100/Double.parseDouble(pred1Str)));
            match.appendChild(pred1);

            org.w3c.dom.Element predX = (org.w3c.dom.Element) document.createElement("PredX");
            predX.setTextContent(String.format("%.2f", 100/Double.parseDouble(predXStr)));
            match.appendChild(predX);

            org.w3c.dom.Element pred2 = (org.w3c.dom.Element) document.createElement("Pred2");
            pred2.setTextContent(String.format("%.2f", 100/Double.parseDouble(pred2Str)));
            match.appendChild(pred2);

            org.w3c.dom.Element predMatchScore = (org.w3c.dom.Element) document.createElement("PredMatchScore");
            predMatchScore.setTextContent(predMatchScoreStr);
            match.appendChild(predMatchScore);

            org.w3c.dom.Element matchScore = (org.w3c.dom.Element) document.createElement("MatchScore");
            matchScore.setTextContent(matchScoreStr);
            match.appendChild(matchScore);

            File dirLevel3 = new File(path + "\\" + dirLevel3Name);
            boolean createdDirLevel3 = dirLevel3.mkdir();
            if(createdDirLevel3)
                System.out.println("-- Folder '"+ dirLevel3.getName() +"' has been created");

            // Сохранить текстовое представление XML документа в файл
            String xmlFileName = (homeTeamStr + " - " + awayTeamStr).replaceAll("/", " + ");
            System.out.print(">>>> '" + xmlFileName.trim() + "'");


            Transformer transformer = TransformerFactory.newInstance()
                    .newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            DOMSource source = new DOMSource((org.w3c.dom.Node) document);
            String endPathFile = dirLevel3.getAbsolutePath() + "/" + xmlFileName + ".xml";
            StreamResult result = new StreamResult(new FileOutputStream(endPathFile));
            transformer.transform(source, result);

            System.out.println(" -> xml file saved!");

        } catch (TransformerConfigurationException ex) {
            ex.printStackTrace();
        } catch (TransformerException ex) {
            ex.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        }
    }


    public static void setInfoXML(String path, String leagueStr, String dateStr,
                                  String homeTeamStr, String awayTeamStr, String predMatchScoreStr, String matchScoreStr){
        try {
            org.w3c.dom.Document document = (org.w3c.dom.Document) DocumentBuilderFactory.newInstance()
                    .newDocumentBuilder().newDocument();

            org.w3c.dom.Element matches = document.createElement("Matches");
            document.appendChild(matches);

            org.w3c.dom.Element match = document.createElement("Match");
            matches.appendChild(match);

            org.w3c.dom.Element sport = (org.w3c.dom.Element) document.createElement("Sport");
            sport.setTextContent("Soccer");
            match.appendChild(sport);

            org.w3c.dom.Element sourceMtch = (org.w3c.dom.Element) document.createElement("Source");
            sourceMtch.setTextContent("Fupro.de");
            match.appendChild(sourceMtch);

            org.w3c.dom.Element league = (org.w3c.dom.Element) document.createElement("League");
            league.setTextContent(leagueStr);
            match.appendChild(league);

            org.w3c.dom.Element date = (org.w3c.dom.Element) document.createElement("Date");
            date.setTextContent(correctDate(dateStr));
            match.appendChild(date);

            org.w3c.dom.Element homeTeam = (org.w3c.dom.Element) document.createElement("HomeTeam");
            homeTeam.setTextContent(homeTeamStr);
            match.appendChild(homeTeam);

            org.w3c.dom.Element awayTeam = (org.w3c.dom.Element) document.createElement("AwayTeam");
            awayTeam.setTextContent(awayTeamStr);
            match.appendChild(awayTeam);

            org.w3c.dom.Element predMatchScore = (org.w3c.dom.Element) document.createElement("PredMatchScore");
            predMatchScore.setTextContent(predMatchScoreStr);
            match.appendChild(predMatchScore);

            org.w3c.dom.Element matchScore = (org.w3c.dom.Element) document.createElement("MatchScore");
            matchScore.setTextContent(matchScoreStr);
            match.appendChild(matchScore);

            File dirLevel3 = new File(path + "\\" + dirLevel3Name);
            boolean createdDirLevel3 = dirLevel3.mkdir();
            if(createdDirLevel3)
                System.out.println("-- Folder '"+ dirLevel3.getName() +"' has been created");

            // Сохранить текстовое представление XML документа в файл
            String xmlFileName = (homeTeamStr + " - " + awayTeamStr).replaceAll("/", " + ");
            System.out.print(">>>> '" + xmlFileName.trim() + "'");


            Transformer transformer = TransformerFactory.newInstance()
                    .newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            DOMSource source = new DOMSource((org.w3c.dom.Node) document);
            String endPathFile = dirLevel3.getAbsolutePath() + "/" + xmlFileName + ".xml";
            StreamResult result = new StreamResult(new FileOutputStream(endPathFile));
            transformer.transform(source, result);

            System.out.println(" -> xml file saved!");

        } catch (TransformerConfigurationException ex) {
            ex.printStackTrace();
        } catch (ParserConfigurationException ex) {
            ex.printStackTrace();
        }catch (TransformerException ex) {
            ex.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static String dateWithDash(String date){
        String[] mass = null;
        if(date.contains(".")) mass = date.split(".");
        else return date;

        return mass[2]+"-"+mass[1]+"-"+mass[0];
    }



}
